﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CaseStudy.Models;

namespace CaseStudy.Data
{
    public class PetsController : Controller
    {
        private readonly PetsContext _context;
        public Owner owner1 = null;
        public PetsController(PetsContext context)
        {
            _context = context;
            
        }

        // GET: Pets
        public async Task<IActionResult> Index(int? id)
        {
            Owner owner = _context.Owners.Select(x => x).Where(x => x.ID == 1).FirstOrDefault();
            _context.Entry(owner).Collection(o => o.Pets).Load();
             
            return View(await _context.Pets.ToListAsync());
        }

        // GET: Pets/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            
            var pet = await _context.Pets
                .FirstOrDefaultAsync(m => m.ID == id);
            
            if (pet == null)
            {
                return NotFound();
            }
            
            return View(pet);
        }

        // GET: Pets/Create
        public IActionResult Create()
        {
            
            return View();
        }

        // POST: Pets/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
                                                //OwnerID - 
        public async Task<IActionResult> Create(int OwnerID,[Bind("ID,Name,Type,Age")] Pet pet)
        {
            OwnerID = pet.ID;
            pet.ID = 0;
            owner1 = _context.Owners.Select(x => x).Where(x => x.ID == OwnerID).FirstOrDefault();

            pet.Owner = owner1;

            if (ModelState.IsValid)
            {
                _context.Add(pet);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index","Owners", new { id = OwnerID});
            }
            return View(pet);
        }
        // GET: Pets/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pet = await _context.Pets.FindAsync(id);

            if (pet == null)
            {
                return NotFound();
            }
            return View(pet);
        }

        // POST: Pets/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,Type,Age")] Pet pet)
        {
            if (id != pet.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pet);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PetExists(pet.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(pet);
        }

        // GET: Pets/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pet = await _context.Pets
                .FirstOrDefaultAsync(m => m.ID == id);
            
            if (pet == null)
            {
                return NotFound();
            }

            return View(pet);
        }

        // POST: Pets/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pet = await _context.Pets.FindAsync(id);

            int ownerID_ = pet.Owner.ID;
            var ow = _context.Owners.Include("");
            _context.Pets.Remove(pet);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Owners", new { id = ownerID_ });
        }

        private bool PetExists(int id)
        {
            return _context.Pets.Any(e => e.ID == id);
        }
    }
}
