﻿using CaseStudy.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudy.Data
{
    public class PetsContext : DbContext
    {
        public PetsContext(DbContextOptions<PetsContext> options) : base(options)
        {
        }

        public DbSet<Pet> Pets { set; get; }
        public DbSet<Owner> Owners{ set; get; }
        public DbSet<Treatment> Treatments { set; get; }
        public DbSet<Vaccination> Vaccinations { set; get; }
        public DbSet<User> Users { set; get; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Pet>().ToTable("Pet");
            modelBuilder.Entity<Owner>().ToTable("Owner");
            modelBuilder.Entity<Treatment>().ToTable("Treatment");
            modelBuilder.Entity<Vaccination>().ToTable("Vaccination");
            modelBuilder.Entity<User>().ToTable("User");
            base.OnModelCreating(modelBuilder);
        }

    }
}
