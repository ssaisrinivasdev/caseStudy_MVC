﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudy.Models
{
    public class Pet
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        public string Type { get; set; }
        public int Age { get; set; }

        public virtual Owner Owner { get; set; }
        public ICollection<Treatment> Treatments { get; set; }
        public ICollection<Vaccination> Vaccinations { get; set; }

    }
}
