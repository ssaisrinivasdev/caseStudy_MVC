﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CaseStudy.Models
{
    
    public class Owner
    {
        [Key]
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required][MinLength(3)][MaxLength(25)]
        public string UserName { get; set; }
        public string Address { get; set; }
        public int Contact { get; set; }

        
        public ICollection<Pet> Pets { get; set; }
    }
}
